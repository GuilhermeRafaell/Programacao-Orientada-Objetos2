package br.com.trabalhofinal.model.Enum;

public enum EnumFuncaoDeAtivacao {
	SOFTMAX,
	SIGMOIDE_LOGISTICA,
	TANGENTE_HIPERBOLICA
}
