package br.com.trabalhofinal.model.Enum;

public enum EnumAvaliacao {
	INSATISFATORIO,
	REGULAR,
	BOM,
	MUITO_BOM
}
