package br.com.trabalhofinal.model.Enum;

public enum EnumTipoTarefa {
	CLASSIFICACAO,
	REGRESSAO
}
