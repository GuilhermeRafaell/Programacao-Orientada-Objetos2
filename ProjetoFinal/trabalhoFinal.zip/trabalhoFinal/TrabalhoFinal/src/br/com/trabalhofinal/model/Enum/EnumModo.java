package br.com.trabalhofinal.model.Enum;

public enum EnumModo {
	UNFITTED,
	ITERFIT,
	FITTED
}
