package br.com.trabalhofinal.model.Enum;

public enum EnumMedidaDeProximidade {
	DISTANCIA_EUCLIDIANA,
	DISTANCIA_DE_MANHATTAN,
	DISTANCIA_DE_MINKOWSKI
}
